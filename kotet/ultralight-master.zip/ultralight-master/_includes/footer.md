Super lightweight Jekyll theme [ultralight](https://github.com/kotet/ultralight)  
[Twitter](https://twitter.com/kotetttt)
| [GitHub](https://github.com/kotet)