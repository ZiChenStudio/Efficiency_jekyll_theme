---
layout: page
title: About
permalink: /about/
---

## 联系我们
如果你要联系我们，请选择下面任意一种联系方式

---
邮箱联系
<br>
```
zichenstudio@outlook.com
```
---
BiliBili<br>

[个人主页](https://space.bilibili.com/1740643474)

---
目前，我们只有以上两个联系方式，首选第一个，如果您使用第二种联系方式(BiliBili)，我们将不会把**您的名字(昵称)**和**个人网站(博客等，如果没有默认以邮箱代替)**放在特别鸣谢的名单中。
## 开发者
ZiChenStudio & ZiChen Official Team
> Tips:其实是一个团队。
## 特别鸣谢
> 参见[*特别鸣谢*](https://zichenstudio.github.io/HTML/thanks.html)
<!-- Copyright (c) 2022, ZiChenStudio Official -->
